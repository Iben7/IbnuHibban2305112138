const modal = document.getElementById('movieModal');
const modalTitle = document.getElementById('modalTitle');
const modalDesc = document.getElementById('modalDesc');
const closeBtn = document.querySelector('.close-btn');

document.querySelectorAll('.details-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const title = btn.dataset.title;
        const desc = btn.dataset.desc;
        modalTitle.textContent = title;
        modalDesc.textContent = desc;
        modal.style.display = 'block';
    });
});

closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', e => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});
