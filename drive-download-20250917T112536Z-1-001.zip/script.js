// Toggle daftar kota
document.getElementById('toggleCities').addEventListener('click', () => {
    const cities = document.getElementById('cities');
    if (cities.style.display === 'block') {
        cities.style.display = 'none';
    } else {
        cities.style.display = 'block';
        // Animasi fade-in
        cities.style.opacity = 0;
        let opacity = 0;
        const fade = setInterval(() => {
            opacity += 0.1;
            cities.style.opacity = opacity;
            if (opacity >= 1) clearInterval(fade);
        }, 30);
    }
});
