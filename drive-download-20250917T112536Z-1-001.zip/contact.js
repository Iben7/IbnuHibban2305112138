// Ambil semua tombol Lihat Detail
const buttons = document.querySelectorAll('.details-btn');

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const desc = button.dataset.desc; // Ambil deskripsi dari atribut data-desc
        const descContainer = button.nextElementSibling;

        // Jika deskripsi sudah ditampilkan, sembunyikan
        if (descContainer.style.display === 'block') {
            descContainer.style.display = 'none';
            descContainer.textContent = '';
            button.textContent = 'Lihat Detail';
        } else {
            // Sembunyikan deskripsi lain jika ada
            document.querySelectorAll('.movie-desc').forEach(d => {
                d.style.display = 'none';
                d.textContent = '';
            });
            document.querySelectorAll('.details-btn').forEach(b => {
                b.textContent = 'Lihat Detail';
            });

            // Tampilkan deskripsi untuk film ini
            descContainer.textContent = desc;
            descContainer.style.display = 'block';
            button.textContent = 'Tutup Detail';
        }
    });
});
